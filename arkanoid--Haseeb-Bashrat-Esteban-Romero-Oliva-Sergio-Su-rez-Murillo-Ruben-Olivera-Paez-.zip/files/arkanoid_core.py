"""Utilidades comunes para el hito M2 de Arkanoid (versión mejorada).

Este módulo proporciona la clase `ArkanoidGame` con toda la infraestructura del
minijuego (constantes, estado compartido y utilidades) y dos decoradores:

* `arkanoid_method`: sustituye un método ya existente de la clase (los TODO).
* `arkanoid_extra`: añade métodos nuevos a la clase (extras de la versión mejorada).

Novedades: varios niveles, temas de color, efectos de sonido generados por
código (no hacen falta ficheros .wav), partículas, power-ups, bloques duros e
indestructibles, combos, récord guardado en disco y estados de juego.
"""

from __future__ import annotations

import array
import math
import os
import random
from collections import deque
from pathlib import Path
from typing import Callable, Iterable, Iterator, TypeVar

import pygame
from pygame import Vector2

__all__ = ["ArkanoidGame", "arkanoid_method", "arkanoid_extra", "pygame", "Vector2"]

F = TypeVar("F", bound=Callable[..., object])

RECORD_FILE = Path(__file__).with_name("arkanoid_record.txt")


class ArkanoidGame:
    """Contenedor con la lógica común del Arkanoid simplificado."""

    # Configuración visual y de juego
    SCREEN_WIDTH: int = 800
    SCREEN_HEIGHT: int = 600
    FPS: int = 60

    BACKGROUND_COLOR = (12, 20, 32)
    PADDLE_COLOR = (230, 230, 240)
    BALL_COLOR = (255, 245, 235)
    TEXT_COLOR = (240, 240, 245)
    ACCENT_COLOR = (255, 214, 102)

    # Un degradado (arriba, abajo) por nivel; se repiten cíclicamente
    LEVEL_THEMES = [
        ((12, 20, 32), (30, 50, 86)),    # azul noche
        ((26, 12, 38), (82, 30, 96)),    # púrpura
        ((8, 30, 28), (24, 94, 78)),     # verde esmeralda
        ((38, 16, 14), (110, 44, 36)),   # rojo ladrillo
        ((8, 8, 22), (52, 26, 108)),     # espacio profundo
    ]

    # Paleta
    PADDLE_SIZE = (120, 18)
    PADDLE_WIDE_WIDTH = 180
    PADDLE_OFFSET = 48
    PADDLE_SPEED = 8.0

    # Bola
    BALL_RADIUS = 10
    BALL_SPEED = 6.0
    BALL_SPEED_PER_LEVEL = 0.6
    BALL_SPEED_MAX = 10.0
    SLOW_FACTOR = 0.6

    # Bloques
    BLOCK_WIDTH = 60
    BLOCK_HEIGHT = 24
    BLOCK_GAP_X = 8
    BLOCK_GAP_Y = 6
    BLOCK_OFFSET_TOP = 80
    MAX_COLUMNS = 11

    BLOCK_COLORS = {
        "#": (214, 103, 103),   # rojo
        "@": (102, 170, 214),   # azul
        "%": (234, 190, 104),   # dorado
        "$": (110, 200, 130),   # verde
        "+": (176, 122, 220),   # morado
        "&": (200, 205, 215),   # plateado: aguanta 2 golpes
        "X": (92, 96, 108),     # gris: indestructible
    }
    BLOCK_POINTS = {
        "#": 50,
        "@": 75,
        "%": 120,
        "$": 100,
        "+": 90,
        "&": 150,
        "X": 0,
    }
    BLOCK_HITS = {"&": 2}              # por defecto, 1 golpe
    UNBREAKABLE = {"X"}
    DAMAGED_COLOR = (140, 145, 160)

    # Power-ups: letra -> (color, nombre)
    POWERUP_TYPES = {
        "W": ((102, 170, 214), "Paleta ancha"),
        "S": ((234, 190, 104), "Bola lenta"),
        "L": ((230, 100, 150), "Vida extra"),
    }
    POWERUP_CHANCE = 0.18
    POWERUP_SPEED = 3
    POWERUP_DURATION = 600             # fotogramas (10 s a 60 FPS)
    MAX_LIVES = 5

    # Entradas y eventos (para minimizar el uso directo de pygame en la plantilla)
    KEY_LEFT = pygame.K_LEFT
    KEY_RIGHT = pygame.K_RIGHT
    KEY_A = pygame.K_a
    KEY_D = pygame.K_d
    KEY_ESCAPE = pygame.K_ESCAPE
    KEY_SPACE = pygame.K_SPACE
    KEY_RETURN = pygame.K_RETURN
    KEY_P = pygame.K_p

    EVENT_QUIT = pygame.QUIT
    EVENT_KEYDOWN = pygame.KEYDOWN
    EVENT_MOUSEMOTION = pygame.MOUSEMOTION
    EVENT_MOUSEBUTTON = pygame.MOUSEBUTTONDOWN

    def __init__(self, level_path: str | os.PathLike[str] | Iterable[str | os.PathLike[str]]) -> None:
        # Se acepta un fichero, una carpeta (todos sus .txt, ordenados) o varios ficheros
        self.level_paths: list[Path] = self._resolver_niveles(level_path)
        if self.level_paths:
            self.level_path = self.level_paths[0]
        elif isinstance(level_path, (str, os.PathLike)):
            self.level_path = Path(level_path)
        else:
            self.level_path = Path(".")
        self.level_index: int = 0
        self.layout: list[str] = []

        # Entidades
        self.paddle = self.crear_rect(0, 0, *self.PADDLE_SIZE)
        self.blocks: list[pygame.Rect] = []
        self.block_colors: list[tuple[int, int, int]] = []
        self.block_symbols: list[str] = []
        self.block_hits: list[int] = []
        self.ball_pos = Vector2(0, 0)
        self.ball_velocity = Vector2(0, 0)
        self.ball_launched: bool = False
        self.trail: deque[Vector2] = deque(maxlen=10)

        # Extras: power-ups, partículas, combos
        self.powerups: list[dict] = []
        self.particles: list[list] = []
        self.combo: int = 0
        self.widen_timer: int = 0
        self.slow_timer: int = 0

        # Estado del juego
        self.score: int = 0
        self.high_score: int = 0
        self.lives: int = 3
        self.running: bool = False
        self.end_message: str = ""
        self.state: str = "menu"   # menu, listo, jugando, pausa, nivel_completo, victoria, gameover
        self.previous_state: str = "listo"
        self.state_timer: int = 0

        # Recursos de pygame
        self.screen: pygame.Surface | None = None
        self.clock: pygame.time.Clock | None = None
        self._fonts: dict[int, pygame.font.Font] = {}
        self.fondo: pygame.Surface | None = None
        self.stars: list[list[float]] = []
        self.sonidos: dict[str, pygame.mixer.Sound] = {}

    # ------------------------------------------------------------------ #
    # Métodos auxiliares ya implementados para el hito
    # ------------------------------------------------------------------ #
    @staticmethod
    def _resolver_niveles(entrada) -> list[Path]:
        if isinstance(entrada, (str, os.PathLike)):
            rutas = [Path(entrada)]
        else:
            rutas = [Path(p) for p in entrada]
        resultado: list[Path] = []
        for ruta in rutas:
            if ruta.is_dir():
                resultado.extend(sorted(ruta.glob("*.txt")))
            else:
                resultado.append(ruta)
        return resultado

    def velocidad_bola(self) -> float:
        """La bola se acelera un poco en cada nivel."""
        return min(self.BALL_SPEED + self.BALL_SPEED_PER_LEVEL * self.level_index, self.BALL_SPEED_MAX)

    def reiniciar_bola(self, direction: Vector2 | Iterable[float] = (0, -1)) -> None:
        """Coloca la bola justo encima de la paleta; espera a ser lanzada."""
        if isinstance(direction, Vector2):
            direccion = direction
        else:
            direccion = Vector2(direction)

        if direccion.length_squared() == 0:
            direccion = Vector2(0, -1)

        self.ball_pos.update(self.paddle.centerx, self.paddle.top - self.BALL_RADIUS - 1)
        self.ball_velocity = direccion.normalize() * self.velocidad_bola()
        self.ball_launched = False
        self.trail.clear()

    def bloques_restantes(self) -> int:
        """Número de bloques que aún hay que destruir (los indestructibles no cuentan)."""
        return sum(1 for s in self.block_symbols if s not in self.UNBREAKABLE)

    def calcular_posicion_bloque(self, fila: int, columna: int) -> pygame.Rect:
        """Convierte coordenadas de cuadrícula en un rectángulo de pygame."""
        if not self.layout:
            raise RuntimeError("No se ha cargado ningún nivel todavía.")

        columnas = len(self.layout[0])
        if columnas <= 0:
            raise ValueError("El nivel debe tener al menos una columna.")

        total_ancho = columnas * self.BLOCK_WIDTH + (columnas - 1) * self.BLOCK_GAP_X
        margen_x = max(0, (self.SCREEN_WIDTH - total_ancho) // 2)

        x = margen_x + columna * (self.BLOCK_WIDTH + self.BLOCK_GAP_X)
        y = self.BLOCK_OFFSET_TOP + fila * (self.BLOCK_HEIGHT + self.BLOCK_GAP_Y)
        return self.crear_rect(x, y, self.BLOCK_WIDTH, self.BLOCK_HEIGHT)

    def inicializar_pygame(self) -> None:
        """Inicializa pygame, la ventana, el sonido y los recursos principales."""
        if self.screen is not None:
            return

        # Permite ejecutar en entornos sin servidor gráfico (tests/CI).
        if "SDL_VIDEODRIVER" not in os.environ and not os.environ.get("DISPLAY"):
            os.environ["SDL_VIDEODRIVER"] = "dummy"
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

        # Mezclador mono de 16 bits: así sabemos qué formato tienen los sonidos
        try:
            pygame.mixer.init(44100, -16, 1, 512, allowedchanges=0)
        except pygame.error:
            pass

        pygame.init()
        pygame.display.set_caption("Arkanoid M2")
        self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()

        self.stars = [
            [random.uniform(0, self.SCREEN_WIDTH), random.uniform(0, self.SCREEN_HEIGHT),
             random.uniform(0.2, 1.2)]
            for _ in range(70)
        ]
        self.crear_sonidos()

    def iterar_eventos(self) -> Iterator[pygame.event.Event]:
        """Itera sobre la cola de eventos de pygame."""
        return iter(pygame.event.get())

    def _obtener_fuente(self, grande: bool, tamano: int | None = None) -> pygame.font.Font | None:
        if not pygame.font:
            return None
        if tamano is None:
            tamano = 48 if grande else 26
        if tamano not in self._fonts:
            self._fonts[tamano] = pygame.font.Font(None, tamano)
        return self._fonts[tamano]

    def dibujar_texto(
        self,
        texto: str,
        posicion: tuple[int, int],
        grande: bool = False,
        color: tuple[int, int, int] | None = None,
        centrado: bool = False,
        tamano: int | None = None,
    ) -> None:
        """Dibuja texto con sombra. Si `centrado`, `posicion` es el centro del texto."""
        if not self.screen:
            return

        fuente = self._obtener_fuente(grande, tamano)
        if not fuente:
            return

        sombra = fuente.render(texto, True, (0, 0, 0))
        superficie = fuente.render(texto, True, color or self.TEXT_COLOR)
        if centrado:
            rect = superficie.get_rect(center=posicion)
        else:
            rect = superficie.get_rect(topleft=posicion)
        self.screen.blit(sombra, rect.move(2, 2))
        self.screen.blit(superficie, rect)

    # ------------------------------------------------------------------ #
    # Sonido (sintetizado por código: no hacen falta ficheros de audio)
    # ------------------------------------------------------------------ #
    def generar_sonido(
        self,
        notas: list[float],
        duracion: float,
        volumen: float = 0.3,
        forma: str = "square",
        barrido: float = 0.0,
    ) -> pygame.mixer.Sound | None:
        """Crea un sonido a partir de una secuencia de notas (Hz)."""
        inicio = pygame.mixer.get_init()
        if not inicio:
            return None
        frecuencia_mezclador, _, canales = inicio

        muestras = int(frecuencia_mezclador * duracion)
        datos = array.array("h")
        fase = 0.0
        for i in range(muestras):
            t = i / muestras
            nota = notas[min(int(t * len(notas)), len(notas) - 1)]
            fase += 2 * math.pi * nota * (1 + barrido * t) / frecuencia_mezclador
            if forma == "square":
                onda = 1.0 if math.sin(fase) >= 0 else -1.0
            elif forma == "saw":
                onda = 2 * ((fase / (2 * math.pi)) % 1.0) - 1
            else:
                onda = math.sin(fase)
            envolvente = min(1.0, i / 80) * (1 - t) ** 1.5
            valor = int(32767 * volumen * envolvente * onda)
            for _ in range(canales):
                datos.append(valor)
        return pygame.mixer.Sound(buffer=datos.tobytes())

    def crear_sonidos(self) -> None:
        """Genera todos los efectos de sonido del juego."""
        self.sonidos.clear()
        inicio = pygame.mixer.get_init()
        if not inicio or inicio[1] != -16:
            return

        efectos = {
            "pared": ([300], 0.06, 0.20, "square", 0.0),
            "paleta": ([200, 260], 0.09, 0.28, "square", 0.3),
            "duro": ([180], 0.09, 0.30, "saw", 0.0),
            "lanzar": ([300, 450, 600], 0.12, 0.25, "sine", 0.0),
            "powerup": ([440, 660, 880], 0.25, 0.30, "sine", 0.0),
            "vida": ([320, 240, 160, 110], 0.50, 0.30, "saw", -0.2),
            "nivel": ([523, 659, 784, 1046], 0.60, 0.28, "square", 0.0),
            "victoria": ([523, 659, 784, 1046, 784, 1046, 1318], 1.10, 0.28, "square", 0.0),
            "gameover": ([392, 330, 262, 196], 0.90, 0.30, "saw", 0.0),
        }
        for nombre, (notas, dur, vol, forma, barrido) in efectos.items():
            sonido = self.generar_sonido(notas, dur, vol, forma, barrido)
            if sonido:
                self.sonidos[nombre] = sonido

        # El sonido de romper bloque sube de tono con el combo
        for n in range(8):
            sonido = self.generar_sonido([440 * 2 ** (n / 6)], 0.09, 0.28, "square")
            if sonido:
                self.sonidos[f"bloque{n}"] = sonido

    def reproducir(self, nombre: str) -> None:
        sonido = self.sonidos.get(nombre)
        if sonido:
            sonido.play()

    # ------------------------------------------------------------------ #
    # Fondo, partículas y récord
    # ------------------------------------------------------------------ #
    def construir_fondo(self) -> None:
        """Degradado vertical según el nivel actual."""
        arriba, abajo = self.LEVEL_THEMES[self.level_index % len(self.LEVEL_THEMES)]
        superficie = pygame.Surface((self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
        for y in range(self.SCREEN_HEIGHT):
            t = y / (self.SCREEN_HEIGHT - 1)
            color = tuple(int(arriba[i] + (abajo[i] - arriba[i]) * t) for i in range(3))
            pygame.draw.line(superficie, color, (0, y), (self.SCREEN_WIDTH, y))
        self.fondo = superficie

    def dibujar_fondo(self) -> None:
        if not self.screen:
            return
        if self.fondo is None:
            self.construir_fondo()
        self.screen.blit(self.fondo, (0, 0))
        for estrella in self.stars:
            estrella[1] += estrella[2]
            if estrella[1] > self.SCREEN_HEIGHT:
                estrella[1] = 0
                estrella[0] = random.uniform(0, self.SCREEN_WIDTH)
            brillo = int(90 + 110 * estrella[2] / 1.2)
            tam = 1 if estrella[2] < 0.7 else 2
            pygame.draw.rect(self.screen, (brillo, brillo, brillo), (estrella[0], estrella[1], tam, tam))

    def crear_particulas(self, centro: tuple[int, int], color: tuple[int, int, int], cantidad: int = 14) -> None:
        for _ in range(cantidad):
            angulo = random.uniform(0, 2 * math.pi)
            velocidad = random.uniform(1.0, 5.0)
            self.particles.append([
                Vector2(centro),
                Vector2(math.cos(angulo), math.sin(angulo)) * velocidad,
                random.randint(20, 40),
                color,
            ])

    def actualizar_particulas(self) -> None:
        for p in self.particles:
            p[0] += p[1]
            p[1].y += 0.12
            p[2] -= 1
        self.particles = [p for p in self.particles if p[2] > 0]

    def dibujar_particulas(self) -> None:
        if not self.screen:
            return
        for posicion, _, vida, color in self.particles:
            tam = max(1, vida // 9)
            pygame.draw.rect(self.screen, color, (posicion.x, posicion.y, tam, tam))

    def cargar_record(self) -> None:
        try:
            self.high_score = int(RECORD_FILE.read_text().strip())
        except (OSError, ValueError):
            self.high_score = 0

    def guardar_record(self) -> None:
        if self.score > self.high_score:
            self.high_score = self.score
            try:
                RECORD_FILE.write_text(str(self.high_score))
            except OSError:
                pass

    # ------------------------------------------------------------------ #
    # Utilidades que encapsulan operaciones habituales de pygame
    # ------------------------------------------------------------------ #
    def crear_rect(self, x: int, y: int, width: int, height: int) -> pygame.Rect:
        """Crea un rectángulo de pygame."""
        return pygame.Rect(x, y, width, height)

    def obtener_rect_bola(self) -> pygame.Rect:
        """Devuelve un rectángulo posicionado sobre la bola actual."""
        return self.crear_rect(
            int(self.ball_pos.x - self.BALL_RADIUS),
            int(self.ball_pos.y - self.BALL_RADIUS),
            self.BALL_RADIUS * 2,
            self.BALL_RADIUS * 2,
        )

    def obtener_estado_teclas(self) -> pygame.key.ScancodeWrapper:
        """Devuelve el estado actual del teclado."""
        return pygame.key.get_pressed()

    def dibujar_rectangulo(
        self, rect: pygame.Rect, color: tuple[int, int, int], borde: int = 0, radio: int = 0
    ) -> None:
        """Dibuja un rectángulo (opcionalmente con esquinas redondeadas)."""
        if not self.screen:
            return
        pygame.draw.rect(self.screen, color, rect, borde, border_radius=radio)

    def dibujar_circulo(self, centro: tuple[int, int], radio: int, color: tuple[int, int, int]) -> None:
        """Dibuja un círculo en pantalla."""
        if not self.screen:
            return
        pygame.draw.circle(self.screen, color, centro, radio)

    def actualizar_pantalla(self) -> None:
        """Refresca el contenido de la ventana principal."""
        if not self.screen:
            return
        pygame.display.flip()

    def esperar(self, milisegundos: int) -> None:
        """Pausa la ejecución el tiempo indicado (en ms)."""
        pygame.time.wait(milisegundos)

    def finalizar_pygame(self) -> None:
        """Cierra pygame y libera la ventana."""
        pygame.quit()
        self.screen = None
        self.clock = None
        self._fonts.clear()
        self.sonidos.clear()

    # ------------------------------------------------------------------ #
    # Métodos a completar por el alumnado (se sobreescriben en la plantilla)
    # ------------------------------------------------------------------ #
    def cargar_nivel(self) -> list[str]:
        raise NotImplementedError

    def preparar_entidades(self) -> None:
        raise NotImplementedError

    def crear_bloques(self) -> None:
        raise NotImplementedError

    def procesar_input(self) -> None:
        raise NotImplementedError

    def actualizar_bola(self) -> None:
        raise NotImplementedError

    def dibujar_escena(self) -> None:
        raise NotImplementedError

    def run(self) -> None:
        raise NotImplementedError


def arkanoid_method(func: F) -> F:
    """Registra `func` como método de `ArkanoidGame`.

    Permite mantener los `TODO` como funciones en `arkanoid_game.py` y que,
    tras importar este módulo, queden enlazadas automáticamente con la clase.
    """
    nombre = func.__name__
    if not hasattr(ArkanoidGame, nombre):
        raise AttributeError(
            f"ArkanoidGame no tiene ningún método llamado {nombre!r} para sobrescribir."
        )

    setattr(ArkanoidGame, nombre, func)
    return func


def arkanoid_extra(func: F) -> F:
    """Añade `func` como método NUEVO de `ArkanoidGame` (no sustituye a ninguno)."""
    setattr(ArkanoidGame, func.__name__, func)
    return func
