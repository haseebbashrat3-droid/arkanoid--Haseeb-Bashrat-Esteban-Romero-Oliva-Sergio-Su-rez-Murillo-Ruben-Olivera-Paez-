"""Arkanoid para el hito M2 (versión mejorada).

Novedades respecto a la plantilla:
  * Varios niveles (carpeta `niveles/`) con dificultad creciente.
  * Más tipos de bloque: colores extra, bloques plateados (2 golpes) y
    bloques grises indestructibles.
  * Power-ups que caen de los bloques: W (paleta ancha), S (bola lenta), L (vida).
  * Efectos de sonido, partículas, estela de la bola, fondos por nivel.
  * Combos, récord guardado, menú, pausa (P), lanzamiento con ESPACIO y ratón.
"""
from arkanoid_core import *
import random
import pygame
from pathlib import Path

# --------------------------------------------------------------------- #
# Métodos a completar por el alumnado
# --------------------------------------------------------------------- #

@arkanoid_method
def cargar_nivel(self) -> list[str]:
    """Lee el fichero de nivel y devuelve la cuadrícula como lista de filas."""
    ruta = Path(self.level_path)
    self.level_path = ruta
    if not ruta.is_file():
        raise FileNotFoundError(f"El fichero de nivel no existe: {ruta}")

    
    filas = ruta.read_text(encoding="utf-8").splitlines()

    if not filas or all(len(fila) == 0 for fila in filas):
        raise ValueError("El fichero de nivel está vacío")

    ancho = len(filas[0])
    if any(len(fila) != ancho for fila in filas):
        raise ValueError("Todas las filas deben tener la misma longitud")

    if ancho > self.MAX_COLUMNS:
        raise ValueError(f"El nivel es demasiado ancho (máximo {self.MAX_COLUMNS} columnas)")

    self.layout = filas

    return self.layout

@arkanoid_method
def preparar_entidades(self) -> None:
    """Posiciona paleta y bola, y reinicia puntuación y vidas."""
    self.paddle.size = self.PADDLE_SIZE

    self.paddle.midbottom = (
        self.SCREEN_WIDTH // 2,
        self.SCREEN_HEIGHT - self.PADDLE_OFFSET
    )

    self.score = 0
    self.lives = 3
    self.end_message = ""
    self.level_index = 0
    self.combo = 0
    self.widen_timer = 0
    self.slow_timer = 0
    self.powerups.clear()
    self.particles.clear()

    self.reiniciar_bola()

@arkanoid_method
def crear_bloques(self) -> None:
    """Genera los rectángulos de los bloques en base a la cuadrícula."""
    self.blocks.clear()
    self.block_colors.clear()
    self.block_symbols.clear()
    self.block_hits.clear()

    for fila in range(len(self.layout)):
        for columna in range(len(self.layout[fila])):
            simbolo = self.layout[fila][columna]

            if simbolo in self.BLOCK_COLORS:
                bloque = self.calcular_posicion_bloque(fila, columna)

                self.blocks.append(bloque)
                self.block_colors.append(self.BLOCK_COLORS[simbolo])
                self.block_symbols.append(simbolo)
                self.block_hits.append(self.BLOCK_HITS.get(simbolo, 1))

@arkanoid_method
def procesar_input(self) -> None:
    """Gestiona la entrada de teclado para mover la paleta."""
    teclas = self.obtener_estado_teclas()

    if teclas[self.KEY_LEFT] or teclas[self.KEY_A]:
        self.paddle.x -= self.PADDLE_SPEED

    if teclas[self.KEY_RIGHT] or teclas[self.KEY_D]:
        self.paddle.x += self.PADDLE_SPEED

    if self.paddle.left < 0:
        self.paddle.left = 0

    if self.paddle.right > self.SCREEN_WIDTH:
        self.paddle.right = self.SCREEN_WIDTH

@arkanoid_method
def actualizar_bola(self) -> None:
    """Actualiza la posición de la bola y resuelve colisiones."""
    if self.end_message:
        return

    if not self.ball_launched:
        self.ball_pos.update(self.paddle.centerx, self.paddle.top - self.BALL_RADIUS - 1)
        return

    if self.bloques_restantes() == 0:
        self.completar_nivel()
        return

    # Estela y movimiento (más lento si hay power-up de bola lenta)
    self.trail.append(Vector2(self.ball_pos))
    factor = self.SLOW_FACTOR if self.slow_timer > 0 else 1.0
    self.ball_pos += self.ball_velocity * factor

    # Rebote contra la pared izquierda
    if self.ball_pos.x - self.BALL_RADIUS <= 0:
        self.ball_pos.x = self.BALL_RADIUS
        self.ball_velocity.x = abs(self.ball_velocity.x)
        self.reproducir("pared")

    # Rebote contra la pared derecha
    elif self.ball_pos.x + self.BALL_RADIUS >= self.SCREEN_WIDTH:
        self.ball_pos.x = self.SCREEN_WIDTH - self.BALL_RADIUS
        self.ball_velocity.x = -abs(self.ball_velocity.x)
        self.reproducir("pared")

    # Rebote contra la pared superior
    if self.ball_pos.y - self.BALL_RADIUS <= 0:
        self.ball_pos.y = self.BALL_RADIUS
        self.ball_velocity.y = abs(self.ball_velocity.y)
        self.reproducir("pared")

    ball_rect = self.obtener_rect_bola()

    # Colisión contra la paleta: el ángulo depende de dónde golpea
    if ball_rect.colliderect(self.paddle) and self.ball_velocity.y > 0:
        self.ball_pos.y = self.paddle.top - self.BALL_RADIUS

        diferencia = (
            self.ball_pos.x - self.paddle.centerx
        ) / (self.paddle.width / 2)
        diferencia = max(-0.9, min(0.9, diferencia))

        self.ball_velocity = Vector2(diferencia, -1).normalize() * self.velocidad_bola()
        self.combo = 0
        self.reproducir("paleta")

    # Colisión contra los bloques
    ball_rect = self.obtener_rect_bola()

    for i, bloque in enumerate(self.blocks):
        if ball_rect.colliderect(bloque):
            # Calculamos el solapamiento entre bola y bloque
            solapamiento_x = min(ball_rect.right, bloque.right) - max(ball_rect.left, bloque.left)
            solapamiento_y = min(ball_rect.bottom, bloque.bottom) - max(ball_rect.top, bloque.top)

            # Rebote en el eje de menor solapamiento y sacamos la bola del bloque
            if solapamiento_x < solapamiento_y:
                self.ball_velocity.x *= -1
                if self.ball_pos.x < bloque.centerx:
                    self.ball_pos.x = bloque.left - self.BALL_RADIUS
                else:
                    self.ball_pos.x = bloque.right + self.BALL_RADIUS
            else:
                self.ball_velocity.y *= -1
                if self.ball_pos.y < bloque.centery:
                    self.ball_pos.y = bloque.top - self.BALL_RADIUS
                else:
                    self.ball_pos.y = bloque.bottom + self.BALL_RADIUS

            self.golpear_bloque(i)
            break

    # Comprobamos si hemos destruido todos los bloques
    if self.bloques_restantes() == 0:
        self.completar_nivel()
        return

    # Comprobamos si la bola ha caído
    if self.ball_pos.y - self.BALL_RADIUS > self.SCREEN_HEIGHT:
        self.perder_vida()

@arkanoid_method
def dibujar_escena(self) -> None:
    """Renderiza fondo, bloques, paleta, bola y HUD."""
    if self.screen is None:
        return

    # Dibujamos el fondo (degradado + estrellas)
    self.dibujar_fondo()

    # Dibujamos los bloques
    for i in range(len(self.blocks)):
        self.dibujar_bloque(i)

    # Power-ups que caen
    for item in self.powerups:
        color, _ = self.POWERUP_TYPES[item["tipo"]]
        self.dibujar_rectangulo(item["rect"], color, radio=9)
        self.dibujar_rectangulo(item["rect"], (255, 255, 255), borde=2, radio=9)
        self.dibujar_texto(item["tipo"], item["rect"].center, color=(20, 20, 30), centrado=True)

    self.dibujar_particulas()

    # Dibujamos la paleta (con borde redondeado y brillo)
    self.dibujar_rectangulo(self.paddle, self.PADDLE_COLOR, radio=8)
    brillo = self.crear_rect(self.paddle.x + 8, self.paddle.y + 3, self.paddle.width - 16, 4)
    self.dibujar_rectangulo(brillo, (255, 255, 255), radio=2)
    if self.widen_timer > 0:
        self.dibujar_rectangulo(self.paddle, self.POWERUP_TYPES["W"][0], borde=2, radio=8)

    # Estela y bola
    for k, punto in enumerate(self.trail):
        fraccion = (k + 1) / (len(self.trail) + 1)
        tono = tuple(int(c * fraccion * 0.7) for c in self.BALL_COLOR)
        self.dibujar_circulo((int(punto.x), int(punto.y)), max(2, int(self.BALL_RADIUS * fraccion)), tono)
    bola_color = self.POWERUP_TYPES["S"][0] if self.slow_timer > 0 else self.BALL_COLOR
    self.dibujar_circulo((int(self.ball_pos.x), int(self.ball_pos.y)), self.BALL_RADIUS, bola_color)

    self.dibujar_hud()
    self.dibujar_estado()

@arkanoid_method
def run(self) -> None:
    """Ejecuta el bucle principal del juego."""
    try:
        import os

        # En Windows no existe la variable DISPLAY. El núcleo la usa para
        # detectar un entorno sin pantalla y fuerza el driver "dummy", que
        # no abre ventana. Un valor cualquiera evita ese atajo; SDL en
        # Windows sigue usando el escritorio real.
        if os.name == "nt" and "SDL_VIDEODRIVER" not in os.environ:
            os.environ.setdefault("DISPLAY", "windows")

        # Inicializamos pygame
        self.inicializar_pygame()
        self.cargar_record()

        # Preparamos los elementos del juego y cargamos el primer nivel
        # (si el fichero es inválido, falla aquí con un mensaje claro)
        self.preparar_entidades()
        self.iniciar_nivel(0)
        self.state = "menu"

        # Activamos el juego
        self.running = True

        # Bucle principal
        while self.running:
            # Procesamos los eventos
            for evento in self.iterar_eventos():
                if evento.type == self.EVENT_QUIT:
                    self.running = False
                else:
                    self.procesar_evento(evento)

            if not self.running:
                break

            if self.state in ("listo", "jugando"):
                # Procesamos el teclado, la bola y los power-ups
                self.procesar_input()
                self.actualizar_bola()
                self.actualizar_powerups()

            self.actualizar_estado()
            self.actualizar_particulas()

            # Dibujamos la escena
            self.dibujar_escena()

            # Actualizamos la pantalla
            self.actualizar_pantalla()

            # Controlamos los FPS
            if self.clock:
                self.clock.tick(self.FPS)

    finally:
        # Guardamos el récord y cerramos pygame al terminar
        self.guardar_record()
        self.finalizar_pygame()


# --------------------------------------------------------------------- #
# Extras de la versión mejorada. Hemos tomado ayuda de otros proyectos ya existentes
# --------------------------------------------------------------------- #

@arkanoid_extra
def iniciar_nivel(self, indice: int) -> None:
    """Carga un nivel, crea sus bloques y deja la bola lista sobre la paleta."""
    self.level_index = indice
    if self.level_paths:
        self.level_path = self.level_paths[indice]
    self.cargar_nivel()
    self.crear_bloques()

    self.powerups.clear()
    self.particles.clear()
    self.combo = 0
    self.widen_timer = 0
    self.slow_timer = 0
    centro = self.paddle.centerx
    self.paddle.width = self.PADDLE_SIZE[0]
    self.paddle.centerx = centro
    self.fondo = None            
    self.reiniciar_bola()
    self.state = "listo"

@arkanoid_extra
def empezar_partida(self) -> None:
    self.preparar_entidades()
    self.iniciar_nivel(0)

@arkanoid_extra
def avanzar_nivel(self) -> None:
    self.iniciar_nivel(self.level_index + 1)

@arkanoid_extra
def completar_nivel(self) -> None:
    self.ball_velocity.update(0, 0)
    self.score += 250 + 50 * self.lives
    self.powerups.clear()
    if self.level_index + 1 < max(1, len(self.level_paths)):
        self.state = "nivel_completo"
        self.state_timer = 150
        self.reproducir("nivel")
    else:
        self.end_message = "¡Has Ganado! :)"
        self.state = "victoria"
        self.reproducir("victoria")
        self.guardar_record()

@arkanoid_extra
def perder_vida(self) -> None:
    self.lives -= 1
    self.combo = 0
    self.powerups.clear()
    self.widen_timer = 0
    self.slow_timer = 0
    centro = self.paddle.centerx
    self.paddle.width = self.PADDLE_SIZE[0]
    self.paddle.centerx = centro

    if self.lives > 0:
        self.reproducir("vida")
        self.reiniciar_bola()
        self.state = "listo"
    else:
        self.end_message = "¡Game Over! :("
        self.ball_velocity.update(0, 0)
        self.state = "gameover"
        self.reproducir("gameover")
        self.guardar_record()

@arkanoid_extra
def golpear_bloque(self, i: int) -> None:
    """Aplica un golpe al bloque `i`: daño, puntos, partículas, power-ups."""
    simbolo = self.block_symbols[i]
    bloque = self.blocks[i]

    if simbolo in self.UNBREAKABLE:
        self.reproducir("duro")
        return

    self.block_hits[i] -= 1
    if self.block_hits[i] > 0:
        # Bloque duro dañado pero todavía en pie
        self.block_colors[i] = self.DAMAGED_COLOR
        self.score += 10
        self.reproducir("duro")
        self.crear_particulas(bloque.center, self.DAMAGED_COLOR, 6)
        return

    # Bloque destruido: puntos + bonus de combo
    self.score += self.BLOCK_POINTS[simbolo] + 10 * min(self.combo, 10)
    self.reproducir(f"bloque{min(self.combo, 7)}")
    self.combo += 1
    self.crear_particulas(bloque.center, self.block_colors[i], 16)

    if random.random() < self.POWERUP_CHANCE:
        tipo = random.choice(list(self.POWERUP_TYPES))
        rect = self.crear_rect(0, 0, 36, 18)
        rect.center = bloque.center
        self.powerups.append({"rect": rect, "tipo": tipo})

    self.blocks.pop(i)
    self.block_colors.pop(i)
    self.block_symbols.pop(i)
    self.block_hits.pop(i)

@arkanoid_extra
def activar_powerup(self, tipo: str) -> None:
    if tipo == "W":
        self.widen_timer = self.POWERUP_DURATION
        centro = self.paddle.centerx
        self.paddle.width = self.PADDLE_WIDE_WIDTH
        self.paddle.centerx = centro
        self.paddle.clamp_ip(self.crear_rect(0, 0, self.SCREEN_WIDTH, self.SCREEN_HEIGHT))
    elif tipo == "S":
        self.slow_timer = self.POWERUP_DURATION
    elif tipo == "L":
        self.lives = min(self.lives + 1, self.MAX_LIVES)

    self.score += 25
    self.reproducir("powerup")
    self.crear_particulas(self.paddle.center, self.POWERUP_TYPES[tipo][0], 12)

@arkanoid_extra
def actualizar_powerups(self) -> None:
    """Mueve las cápsulas que caen, las recoge y gestiona las duraciones."""
    if not self.ball_launched:
        return

    restantes = []
    for item in self.powerups:
        item["rect"].y += self.POWERUP_SPEED
        if item["rect"].colliderect(self.paddle):
            self.activar_powerup(item["tipo"])
        elif item["rect"].top <= self.SCREEN_HEIGHT:
            restantes.append(item)
    self.powerups = restantes

    if self.slow_timer > 0:
        self.slow_timer -= 1

    if self.widen_timer > 0:
        self.widen_timer -= 1
        if self.widen_timer == 0:
            centro = self.paddle.centerx
            self.paddle.width = self.PADDLE_SIZE[0]
            self.paddle.centerx = centro

@arkanoid_extra
def actualizar_estado(self) -> None:
    if self.state == "nivel_completo":
        self.state_timer -= 1
        if self.state_timer <= 0:
            self.avanzar_nivel()

@arkanoid_extra
def accion_principal(self) -> None:
    """Acción de ESPACIO / ENTER / clic según el estado actual."""
    if self.state == "menu":
        self.empezar_partida()
    elif self.state == "listo":
        self.ball_launched = True
        self.state = "jugando"
        self.reproducir("lanzar")
    elif self.state == "nivel_completo":
        self.avanzar_nivel()
    elif self.state in ("victoria", "gameover"):
        self.empezar_partida()
    elif self.state == "pausa":
        self.alternar_pausa()

@arkanoid_extra
def alternar_pausa(self) -> None:
    if self.state in ("listo", "jugando"):
        self.previous_state = self.state
        self.state = "pausa"
    elif self.state == "pausa":
        self.state = self.previous_state

@arkanoid_extra
def procesar_evento(self, evento) -> None:
    if evento.type == self.EVENT_KEYDOWN:
        if evento.key == self.KEY_ESCAPE:
            self.running = False
        elif evento.key in (self.KEY_SPACE, self.KEY_RETURN):
            self.accion_principal()
        elif evento.key == self.KEY_P:
            self.alternar_pausa()
    elif evento.type == self.EVENT_MOUSEBUTTON:
        self.accion_principal()
    elif evento.type == self.EVENT_MOUSEMOTION and self.state in ("listo", "jugando"):
        self.paddle.centerx = evento.pos[0]
        self.paddle.clamp_ip(self.crear_rect(0, 0, self.SCREEN_WIDTH, self.SCREEN_HEIGHT))

@arkanoid_extra
def dibujar_bloque(self, i: int) -> None:
    bloque = self.blocks[i]
    color = self.block_colors[i]
    simbolo = self.block_symbols[i]
    sombra = tuple(int(c * 0.6) for c in color)
    brillo = tuple(min(255, c + 55) for c in color)

    self.dibujar_rectangulo(bloque, color, radio=4)
    franja = self.crear_rect(bloque.x + 4, bloque.y + 3, bloque.width - 8, 4)
    self.dibujar_rectangulo(franja, brillo, radio=2)
    self.dibujar_rectangulo(bloque, sombra, borde=2, radio=4)

    # Grietas en los bloques duros dañados
    if simbolo in self.BLOCK_HITS and self.block_hits[i] < self.BLOCK_HITS[simbolo]:
        puntos = [
            (bloque.x + 14, bloque.y + 2),
            (bloque.x + 24, bloque.y + 12),
            (bloque.x + 18, bloque.y + 16),
            (bloque.x + 30, bloque.bottom - 2),
        ]
        pygame.draw.lines(self.screen, sombra, False, puntos, 2)

    # Los indestructibles llevan una cruz
    if simbolo in self.UNBREAKABLE:
        pygame.draw.line(self.screen, sombra, (bloque.x + 6, bloque.y + 6), (bloque.right - 6, bloque.bottom - 6), 2)
        pygame.draw.line(self.screen, sombra, (bloque.x + 6, bloque.bottom - 6), (bloque.right - 6, bloque.y + 6), 2)

@arkanoid_extra
def dibujar_hud(self) -> None:
    centro_x = self.SCREEN_WIDTH // 2
    self.dibujar_texto(f"Puntuacion: {self.score}", (20, 16))
    self.dibujar_texto(f"Record: {max(self.high_score, self.score)}", (20, 40), color=self.ACCENT_COLOR)

    total = max(1, len(self.level_paths))
    self.dibujar_texto(f"Nivel {self.level_index + 1}/{total}", (centro_x, 26), centrado=True)
    if self.combo >= 2:
        self.dibujar_texto(f"Combo x{self.combo}", (centro_x, 52), color=self.ACCENT_COLOR, centrado=True)

    # Vidas como bolitas
    for k in range(self.lives):
        self.dibujar_circulo((self.SCREEN_WIDTH - 28 - k * 26, 28), 8, self.BALL_COLOR)

    # Power-ups activos
    y = self.SCREEN_HEIGHT - 28
    if self.widen_timer > 0:
        self.dibujar_texto(f"Paleta ancha {self.widen_timer // 60 + 1}s", (20, y), color=self.POWERUP_TYPES["W"][0])
    if self.slow_timer > 0:
        self.dibujar_texto(f"Bola lenta {self.slow_timer // 60 + 1}s", (220, y), color=self.POWERUP_TYPES["S"][0])

@arkanoid_extra
def dibujar_overlay(self, alfa: int) -> None:
    velo = pygame.Surface((self.SCREEN_WIDTH, self.SCREEN_HEIGHT), pygame.SRCALPHA)
    velo.fill((0, 0, 0, alfa))
    self.screen.blit(velo, (0, 0))

@arkanoid_extra
def dibujar_estado(self) -> None:
    cx = self.SCREEN_WIDTH // 2
    cy = self.SCREEN_HEIGHT // 2
    parpadeo = (pygame.time.get_ticks() // 500) % 2 == 0

    if self.state == "menu":
        self.dibujar_overlay(150)
        self.dibujar_texto("ARKANOID", (cx, cy - 90), color=self.ACCENT_COLOR, centrado=True, tamano=110)
        if parpadeo:
            self.dibujar_texto("Pulsa ESPACIO para empezar", (cx, cy + 10), grande=True, centrado=True)
        self.dibujar_texto("Flechas / A D / ratón: mover    ESPACIO: lanzar    P: pausa    ESC: salir",
                           (cx, cy + 80), centrado=True)
        self.dibujar_texto("W = paleta ancha   S = bola lenta   L = vida extra", (cx, cy + 110), centrado=True)
    elif self.state == "listo":
        self.dibujar_texto(f"NIVEL {self.level_index + 1}", (cx, cy + 40), grande=True,
                           color=self.ACCENT_COLOR, centrado=True)
        if parpadeo:
            self.dibujar_texto("Pulsa ESPACIO para lanzar", (cx, cy + 80), centrado=True)
    elif self.state == "pausa":
        self.dibujar_overlay(150)
        self.dibujar_texto("PAUSA", (cx, cy), grande=True, centrado=True, tamano=80)
        self.dibujar_texto("Pulsa P para continuar", (cx, cy + 50), centrado=True)
    elif self.state == "nivel_completo":
        self.dibujar_texto(f"¡Nivel {self.level_index + 1} completado!", (cx, cy + 20), grande=True,
                           color=self.ACCENT_COLOR, centrado=True)
    elif self.state in ("victoria", "gameover"):
        self.dibujar_overlay(150)
        self.dibujar_texto(self.end_message, (cx, cy - 20), grande=True, centrado=True, tamano=72)
        self.dibujar_texto(f"Puntuación final: {self.score}", (cx, cy + 40), centrado=True)
        if parpadeo:
            self.dibujar_texto("ESPACIO: jugar otra vez    ESC: salir", (cx, cy + 75), centrado=True)


def main() -> None:
    """Permite ejecutar el juego desde la línea de comandos."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Arkanoid con pygame (hito M2,).",
    )
    parser.add_argument(
        "level",
        type=str,
        nargs="*",
       
    )
    args = parser.parse_args()

    entrada = args.level or [Path(__file__).with_name("niveles")]
    game = ArkanoidGame(entrada)
    game.run()

if __name__ == "__main__":
    main()
